README_BIRDCABLE1_FAB.txt

DATE: 06/19/2019
PART #: BIRDCABLE1
REVISION: A
Design: 300MM Cable

ORGANIZATION:

Gardner-Otchy Lab at Boston University
24 Cummington Mall Rm 424
Boston, MA 02215


ENGINEERING CONTACT INFORMATION:

Haley Fawcett, Undergraduate Researcher
Cell: (617) 794-3247
hfawce@bu.edu


FABRICATION INFORMATION:

Flex Printed Circuit Board
Board Copper Layers: 1
Board Material: Polymide
Polymide Thickness Layer1: 0.025 mm 
Polymide Thickness Layer3: 0.05 mm 
Stiffener Material: FR4 Standard
Stiffener Thickness: 0.75 mm
Cladding: 1oz initial copper on all layers
Finish/Plating: HASL/Leaded Solder

Minimum Design Line Width: 0.125 mm
Minimum Design Spacing: 0.125 mm


FILE LIST:

	Stackup & Artwork:

soldermask_top.gbr		LAYER 1 (POLYMIDE TOP COVER - i.e. SOLDERMASK) THICKNESS: 0.025 mm
copper_tracings.gbr		LAYER 2 (COPPER) 1oz initial
soldermask_bottom.gbr		LAYER 3 (POLYMIDE BOTTOM COVER) THICKNESS: 0.05 mm - NO DESIGN DETAILS ON THIS LAYER
stiffeners_profile.gbr		LAYER 4 (FR4 STIFFENERS) THICKNESS: 0.75 mm
cable_profile.gbr		BOARD OUTLINE


	Fabrication Drawings:

drills.xln			DRILL DRAWING

### END